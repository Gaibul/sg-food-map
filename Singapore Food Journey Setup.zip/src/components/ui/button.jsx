export function Button({ variant='default', size='md', className='', ...props }) {
  const base = 'inline-flex items-center justify-center rounded-2xl shadow-sm px-3 py-2 text-sm transition';
  const variants = {
    default: 'bg-black text-white hover:opacity-90',
    secondary: 'bg-neutral-100 hover:bg-neutral-200',
    outline: 'border border-neutral-300 hover:bg-neutral-50',
    destructive: 'bg-red-600 text-white hover:bg-red-700',
    ghost: 'hover:bg-neutral-100'
  };
  const sizes = { sm:'px-2 py-1 text-xs rounded-xl', md:'', lg:'px-4 py-3 text-base' };
  return <button className={[base, variants[variant]||variants.default, sizes[size]||sizes.md, className].join(' ')} {...props} />
}
